﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Convert : MonoBehaviour
{
    public InputField Inputamount;
    public InputField amount;

    public Toggle USD;
    public Toggle JPY;
    public Toggle MYR;
    public Toggle EURO;


    public float SGDUSD = 0.76f;
    public float SGDYEN = 97.08f;
    public float SGDMYR = 3.27f;
    public float SGDEURO = 0.70f;


    float Amount;
    // Start is called before the first frame update
    void Start()
    {
        USD.isOn = false;
        JPY.isOn = false;
        MYR.isOn = false;
        EURO.isOn = false;

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Convertz()
    {
        Amount = float.Parse(amount.text);

        if (USD.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDUSD);
        }
        if (JPY.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDYEN);
        }
        if (MYR.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDMYR);
        }
        if (EURO.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDEURO);
        }

    }

    public void clear()
    {
        USD.isOn = false;
        JPY.isOn = false;
        EURO.isOn = false;


        Inputamount.text = "";
        amount.text = "";
    }
}
